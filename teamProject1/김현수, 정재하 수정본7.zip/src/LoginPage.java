import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.io.File;

public class LoginPage extends JFrame implements ActionListener{
	FileInputStream f = null;
	JButton LB = new JButton("�α���");
	JButton LSB = new JButton("ȸ������");
	JButton LFID = new JButton("ID ã��");
	JButton LFPW = new JButton("PW ã��");
	JTextField IDtext = new JTextField();
	JPasswordField PWtext = new JPasswordField();
	String z;
	File Datadir = new File(System.getProperty("user.dir") + "\\Data");
	
	public LoginPage() {                                       //�α��� Frame
		super ("�α���");	
		setLayout(new BorderLayout());
		JPanel jp = new JPanel();
		JPanel jp2 = new JPanel();
		JPanel jp3 = new JPanel();
		jp.setLayout(new GridLayout(0,4));
		jp2.setLayout(new GridLayout(2,0));
		jp3.setLayout(new GridLayout(2,0));
		add(jp, "South");
		add(jp2, "Center");
		add(jp3, "West");
		jp3.add(new Label ("ID:"), ("1"));
		jp3.add(new Label ("pw:"), ("2"));
		jp.add(LB,("1"));
		jp.add(LSB,("2"));
		jp.add(LFID,("3"));
		jp.add(LFPW,("4"));
		jp2.add(IDtext,("1"));
		jp2.add(PWtext,("2"));
		
		setVisible(true);
		setSize(400, 150);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		LB.addActionListener(this);
		LSB .addActionListener(this);
		LFID.addActionListener(this);
		LFPW.addActionListener(this);
		setLocation(750,450);
	}	
	boolean LoginID() {                   //id �ߺ� ã��
	
        try {
            String[] dataDirList = Datadir.list();
            for ( String list : dataDirList){
                FileInputStream IDCheck = new FileInputStream(Datadir.getPath() + "\\" + list + "\\ID.txt");
                byte a[] = new byte[IDCheck.available()];
                while(IDCheck.read(a) != -1){}
                String data = new String(a);
                if (IDtext.getText().equals(data))
                {
                 	return true;
                }
           }
        }catch (Exception b){
               return false;
			 }
        return false;
	}
	
	boolean LoginPW () {                  // pw �ߺ� ã��
		
        try {
            String[] dataDirList = Datadir.list();
            for ( String list : dataDirList){
                FileInputStream PWCheck = new FileInputStream(Datadir.getPath() + "\\" + list + "\\PW.txt");
                byte a[] = new byte[PWCheck.available()];           
                while(PWCheck.read(a) != -1){}
                String data = new String(a);
                String str = new String (PWtext.getPassword());
                if (str.equals(data))
                {
                 	return true;
                }
           }
        }catch (Exception b){
			 }
        return false;
	}
	public static void main(String[] args) {          //����
		LoginPage LP = new LoginPage();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == LB) {                             //�α���
			InfoText info = new InfoText();
		    if(LoginPW() && LoginID()) {
		    	info.j4.setText("�����߽��ϴ�.");
		    	info.LoginButtonMessage();
		    	dispose();
		    }else {
		    	info.j4.setText("�����߽��ϴ�.");
		    	info.LoginButtonMessage();
		    }
			
		}else if (e.getSource() == LSB) {                      //ȸ������
			SignUpPage sup = new SignUpPage();
			dispose();
		}else if (e.getSource() == LFID) {                     // IDã��
			dispose();
		   	new FindID();
		}else {                                                  // PWã��
			dispose();
		   	new FindPW();
		}
			
	}
}
