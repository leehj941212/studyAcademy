import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class InfoText extends JFrame implements ActionListener{           // �޽���


		JButton c = new JButton("Ȯ��");
		JButton d = new JButton("Ȯ��");
		JButton f = new JButton("Ȯ��");
		JButton g = new JButton("Ȯ��");
		Label j4 = new Label();
		Label j5 = new Label();
		Label j6 = new Label();
		Label j7 = new Label();
		
	public void LoginButtonMessage() {	              // �α��� ��ư�������� ����޽���
		setLayout(new BorderLayout());
		JPanel jp = new JPanel();
		JPanel jp1 = new JPanel();
		jp.setLayout(new GridLayout(2,0));
		jp1.setLayout(new BorderLayout());
		add(jp, "Center");
		jp.add(jp1,("1"));
		jp.add(c,("2"));
		jp1.add(j4 , "Center");
		setVisible(true);
		setSize(400, 150);
		setLocation(750,450);
		c.addActionListener(this);
	}
	
	public void FindIDMessgae() {                      // IDã�� �޽���
		setLayout(new BorderLayout());
		JPanel jp2 = new JPanel();
		JPanel jp3 = new JPanel();
		jp2.setLayout(new GridLayout(2,0));
		jp3.setLayout(new BorderLayout());
		add(jp2, "Center");
		jp2.add(jp3,("1"));
		jp2.add(d,("2"));
		jp3.add(j5 , "Center");
		setVisible(true);
		setSize(400, 150);
		setLocation(750,450);
		d.addActionListener(this);	
	}
	
	public void FindPWMessgae() {                    // PWã�� �޽���
		setLayout(new BorderLayout());
		JPanel jp4 = new JPanel();
		JPanel jp5 = new JPanel();
		jp4.setLayout(new GridLayout(2,0));
		jp5.setLayout(new BorderLayout());
		add(jp4, "Center");
		jp4.add(jp5,("1"));
		jp4.add(f,("2"));
		jp5.add(j6 , "Center");
		setVisible(true);
		setSize(400, 150);
		setLocation(750,450);
		f.addActionListener(this);	
	}
	
	public void SignUpMessgae() {                    // PWã�� �޽���
		setLayout(new BorderLayout());
		JPanel jp6 = new JPanel();
		JPanel jp7 = new JPanel();
		jp6.setLayout(new GridLayout(2,0));
		jp7.setLayout(new BorderLayout());
		add(jp6, "Center");
		jp6.add(jp7,("1"));
		jp6.add(g,("2"));
		jp7.add(j7 , "Center");
		setVisible(true);
		setSize(400, 150);
		setLocation(750,450);
		g.addActionListener(this);
	}	
	@Override
public void actionPerformed(ActionEvent e) {
		if (e.getSource() == c) {
			if(j4.equals("�����߽��ϴ�")) {				
			}else {
				dispose();
				}
		}		
		if (e.getSource() == d) {	
			dispose();
			new LoginPage();
		}			
		if (e.getSource() == f) {
				dispose();
				new LoginPage();				
		}
		if (e.getSource() == g) {
			if(j7.equals("�����߽��ϴ�.")) {
				dispose();
				new LoginPage();
			}else {
				dispose();
			}
		}
}		
		

	
	
	public static void main(String[] args) {
		
	}
}



