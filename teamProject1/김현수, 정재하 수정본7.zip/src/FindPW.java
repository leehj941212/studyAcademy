import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FindPW extends JFrame implements ActionListener{
	JButton f = new JButton("ã��");
	JButton b = new JButton("���");
	JTextField PNtext = new JTextField();
	JTextField IDtext = new JTextField();
	
	public FindPW() {							//frame
		super ("��й�ȣ ã��");
		setLayout(new BorderLayout());
		JPanel jp = new JPanel();
		JPanel jp2 = new JPanel();
		JPanel jp3 = new JPanel();
		jp.setLayout(new GridLayout(2,0));
		jp2.setLayout(new GridLayout(0,2));	
		jp3.setLayout(new GridLayout(2,0));
		add(jp, "West");
		add(jp2, "South");
		add(jp3, "Center");
		jp.add(new Label ("ID:"), ("1"));
		jp.add(new Label ("��ȭ��ȣ:"), ("2"));
		jp2.add(f, ("1"));
		jp2.add(b, ("2"));
		jp3.add(IDtext, ("1"));
		jp3.add(PNtext, ("2"));
		setVisible(true);
		setSize(300, 150);
		setLocation(750,450);
		b.addActionListener(this);
		f.addActionListener(this);
	}
	
	
	boolean FindPWID () {                           //ID�ߺ�Ȯ��
		 File f = new File("Data");
        try {
            String[] dataDirList = f.list();
            for ( String list : dataDirList){
                FileInputStream IDCheck = new FileInputStream(f.getPath() + "/" + list + "/ID.txt");
                byte a[] = new byte[IDCheck.available()];
                while(IDCheck.read(a) != -1){}
                String data = new String(a);
                if (IDtext.getText().equals(data))
                {
                 	return true;
                }
           }
        }catch (Exception b){
			 }
        return false;
	}
	
	boolean FindPWPN () {							//��ȭ��ȣ�ߺ�Ȯ��
		 File f = new File("Data");
        try {
            String[] dataDirList = f.list();
            for ( String list : dataDirList){
                FileInputStream PN1Check = new FileInputStream(f.getPath() + "/" + list + "/PN.txt");
                byte a[] = new byte[PN1Check.available()];
                while(PN1Check.read(a) != -1){}
                String data = new String(a);
                if (PNtext.getText().equals(data))
                {
                 	return true;
                }
           }
        }catch (Exception b){
			 }
        return false;
	}
	
	public static void main(String[] args) {
		
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		InfoText info = new InfoText();
		if (e.getSource() == b) {
			dispose();
			new LoginPage();
	}else {
		if (FindPWID()&& FindPWPN()) {
			info.FindPWMessgae();
			File f = new File("Data");
			String data = "ff";
	         try {
	             String[] dataDirList = f.list();
                FileInputStream IDcheck = new FileInputStream(f.getPath() + "/" + PNtext.getText() + "/PW.txt");
                byte a[] = new byte[IDcheck.available()];
                while(IDcheck.read(a) != -1){}
                data = new String(a);
                data = "PW : " + data;
	         }catch(Exception ex ) {
	         }
	         info.j6.setText(data);	
			
		}else {
			info.FindPWMessgae();
			info.j6.setText("�Է��Ͻ� ��ȭ��ȣ �Ǵ� ���̵� ��ġ���� �ʽ��ϴ�.");

		}
	}
	}
}


