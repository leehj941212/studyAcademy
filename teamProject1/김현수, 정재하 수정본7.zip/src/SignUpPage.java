import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class SignUpPage extends JFrame implements ActionListener {
    JPanel jp1 = new JPanel();
    JPanel jp2 = new JPanel();
    JPanel jp3 = new JPanel();
    JPanel jp4 = new JPanel();
    JTextField SignUpName = new JTextField();
    JLabel SignUpNameL = new JLabel("�̸��� �Է��ϼ���");
    JTextField SignUpID = new JTextField();
    JButton CheckButton = new JButton(" �ߺ� Ȯ�� ");
    JPasswordField SignUpPW = new JPasswordField(16);

    JLabel SignUpPWL = new JLabel("<html>��й�ȣ�� 8�� �̻�" + "<br>" +"16�� ���Ϸ� �Է��ϼ���<html>");
    JPasswordField SignUpPWC = new JPasswordField(16);
    JLabel SignUpPWCL = new JLabel("���� �����ϰ� �Է��ϼ���");
    JButton SignUpButton = new JButton("�����ϱ�");
    JButton SignUpBack = new JButton("���");
    JLabel CheckLabel = new JLabel("���̵� 2�� �̻� �Է��ϼ���");
    JLabel SignUpPNL = new JLabel("<html>��ȭ��ȣ�� - ���� " + "<br>" +"11�ڸ��� �Է��ϼ���<html>");
    JLabel SignUpBirthL = new JLabel("��������� �����ϼ���");

    JComboBox SignUpYear = new JComboBox();
    JComboBox SignUpMonth = new JComboBox();
    JComboBox SignUpDay = new JComboBox();
    JTextField SignUpPN1 = new JTextField();
    int CheckButtonCount = 0;
//    011 010 016 017 018 019
    public SignUpPage(){              					  //frame
        super("ȸ������");
        setVisible(true);
        setSize(600, 400);
        setLocation(750,450);
        setLayout(new BorderLayout());
        jp1.setLayout(new GridLayout(6, 3));
        jp2.setLayout(new GridLayout(1, 2));
        jp3.setLayout(new FlowLayout());

        add(jp1, BorderLayout.CENTER);
        add(jp2, BorderLayout.SOUTH);

        jp1.add(new JLabel("�̸�"));
        jp1.add(SignUpName);
        jp1.add(SignUpNameL);

        jp1.add(new JLabel("ID"));
        jp1.add(SignUpID);
        jp1.add(jp4);

        jp4.setLayout(new GridLayout( 2, 1));
        jp4.add(CheckButton);
        jp4.add(CheckLabel);

        jp1.add(new JLabel("PW"));
        jp1.add(SignUpPW);
        jp1.add(SignUpPWL);

        jp1.add(new JLabel("PW Ȯ��"));
        jp1.add(SignUpPWC);
        jp1.add(SignUpPWCL);

        jp1.add(new JLabel("�������"));
        jp1.add(jp3);
        jp1.add(SignUpBirthL);

        jp1.add(new JLabel("��ȣ"));
        jp1.add(SignUpPN1);
        jp1.add(SignUpPNL);

        SignUpYear.addItem("��");
        SignUpMonth.addItem("��");
        SignUpDay.addItem("��");
        for ( int i = 1900; i <2023; i ++){
            SignUpYear.addItem(i);
        }
        for ( int j = 1; j< 13; j++){
            SignUpMonth.addItem(j);
        }
        for (int k = 1; k <= 31; k++){
            SignUpDay.addItem(k);
        }

        jp3.setLayout(new FlowLayout());
        jp3.add(SignUpYear);
        jp3.add(new JLabel(" / "));
        jp3.add(SignUpMonth);
        jp3.add(new JLabel(" / "));
        jp3.add(SignUpDay);

        jp2.add(SignUpButton, "�����ϱ�");
        jp2.add(SignUpBack, ("���"));


        CheckButton.addActionListener(this);
        SignUpButton.addActionListener(this);
        SignUpBack.addActionListener(this);

        SignUpID.getDocument().addDocumentListener(new DocumentListener() {       // ID �ߺ�üũ 
            @Override
            public void insertUpdate(DocumentEvent documentEvent) {
            	CheckButtonCount = 0;
            }

            @Override
            public void removeUpdate(DocumentEvent documentEvent) {
            	CheckButtonCount = 0;
            }

            @Override
            public void changedUpdate(DocumentEvent documentEvent) {
                CheckButtonCount = 0;      
            }	
        });
    }
// �� ��ġ��, �ߺ�Ȯ�� ����
    @Override
    public void actionPerformed(ActionEvent actionEvent) {       
        String textID = SignUpID.getText();
        InfoText info = new InfoText();
        if (actionEvent.getSource() == CheckButton) {    //�ߺ� Ȯ�� ��ư
        	File f = new File("Data");
            try {          	
                String[] dataDirList = f.list();
                if (f.list().length == 0) {
                	CheckLabel.setText("��� �����մϴ�.");
                	CheckButtonCount += 1;;
                }else {
	                System.out.println(" ���� ���� ���� ");
	                for (String list : dataDirList) {
	                    FileInputStream IDCheck = new FileInputStream(f.getPath() + "/" + list + "/ID.txt");
	                    byte a[] = new byte[IDCheck.available()];
	                    while (IDCheck.read(a) != -1) { }
	                    String data = new String(a);
	                    if (SignUpID.getText().equals(data)) {
	                        CheckLabel.setText("�ߺ��� ���̵� �����մϴ�.");
	                        break;
	                    } else {
	                        CheckLabel.setText("��� �����մϴ�.");
	                        CheckButtonCount += 1;
	                    }
	                }
                }
            } catch (Exception a) {

            }
        }


        else if (actionEvent.getSource() == SignUpButton) {    // ����Ȯ�� ��ư
            String textName = SignUpName.getText();
            
            String textPW = String.valueOf(SignUpPW.getPassword());
            String a = SignUpPN1.getText();
            String data_path = System.getProperty("user.dir") + "/Data/";
            File f = new File(data_path + a);   
            if(String.valueOf(SignUpPW.getPassword()).equals(String.valueOf(SignUpPWC.getPassword())))
            if( textName.length() < 2) {
            	info.j7.setText("�̸��� 2�� �̻� �Է��ϼ���");
            	info.SignUpMessgae();
            }else if( textID.length() < 2 ) {
            	info.j7.setText("ID 2�� �̻� �Է��ϼ���");
            	info.SignUpMessgae();
            }else if( !(textPW.length() <= 16 && textPW.length() >= 8)) {
            	info.j7.setText("��й�ȣ�� ���ǿ� �°� �Է��ϼ���.");
            	info.SignUpMessgae();
            }else if(!String.valueOf(SignUpPW.getPassword()).equals(String.valueOf(SignUpPWC.getPassword()))) {
            	info.j7.setText("PW�� PWȮ���� �Ȱ��� �Է��ϼ���.");
            	info.SignUpMessgae();
            }else if(SignUpDay.getSelectedItem().toString() == "��" && SignUpMonth.getSelectedItem().toString() == "��"
                    && SignUpYear.getSelectedItem().toString() == "��") {
            	info.j7.setText("��������� �����ϼ���.");
            	info.SignUpMessgae();
            }else if (a.length()!=11) {
            	info.j7.setText("��ȭ��ȣ�� ���ǿ� �°� �Է��ϼ���.");
            	info.SignUpMessgae();
            }
            else if ( CheckButtonCount > 0 ) {
            	info.j7.setText("�ߺ�Ȯ���� ��������");
            	info.SignUpMessgae();
            	if (!f.exists()) {
                    f.mkdir();
                    FileOutputStream Output1 = null;
                    FileOutputStream Output2 = null;
                    FileOutputStream Output3 = null;
                    FileOutputStream Output4 = null;
                    FileOutputStream Output5 = null;
                    try {
                        String f_path = f.getPath();
                        f_path = f_path + "/";

                        Output1 = new FileOutputStream(f_path + "Name.txt");
                        Output2 = new FileOutputStream(f_path + "ID.txt");
                        Output3 = new FileOutputStream(f_path + "PW.txt");
                        Output4 = new FileOutputStream(f_path + "PN.txt");
                        Output5 = new FileOutputStream(f_path + "Birth.txt");

                        String data1 = SignUpName.getText();
                        String data2 = SignUpID.getText();
                        String data3 = SignUpPW.getText();
                        String data4 = SignUpPN1.getText();
                        String data5 = SignUpYear.getSelectedItem().toString() + SignUpMonth.getSelectedItem().toString() +
                                SignUpDay.getSelectedItem().toString();

                        byte data01[] = data1.getBytes();
                        Output1.write(data01);
                        byte data02[] = data2.getBytes();
                        Output2.write(data02);
                        byte data03[] = data3.getBytes();
                        Output3.write(data03);
                        byte data04[] = data4.getBytes();
                        Output4.write(data04);
                        byte data05[] = data5.getBytes();
                        Output5.write(data05);
                        
                        info.j7.setText("�����߽��ϴ�.");
        		    	info.SignUpMessgae();
        		    	dispose();
                    } catch (Exception e) {	

                }
            }
        }else if(CheckButtonCount == 0) {
        	info.j7.setText("�ߺ�Ȯ���� ���ּ���.");
	    	info.SignUpMessgae();
        }
            }else {
        	dispose();
        	new LoginPage();
    	}
    }


            /*
����ϱ�, �����ϱ������� �޽��� + �α���ȭ��, 
     */

    public static void main(String[] args) {
       
    }
}