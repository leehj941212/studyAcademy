import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FindID extends JFrame implements ActionListener {

	JButton f = new JButton("ã��");
	JButton b = new JButton("���");
	JTextField PNtext = new JTextField();
	 String data = new String();
	public FindID() {				//frame
		super("���̵� ã��");
		setLayout(new BorderLayout());
		JPanel jp = new JPanel();
		JPanel jp2 = new JPanel();

		jp2.setLayout(new GridLayout(0, 2));
		jp.setLayout(new GridLayout(0, 2));
		add(new Label("��ȭ��ȣ:"), "West");
		add(PNtext, "Center");
		add(jp2, "South");
		jp2.add(f, ("1"));
		jp2.add(b, ("2"));

		setVisible(true);
		setSize(300, 150);
		setLocation(750,450);
		b.addActionListener(this);
		f.addActionListener(this);
	}
	
	boolean FindIDPN () {					 //��ȭ��ȣ�ߺ�Ȯ��
		 File f = new File("Data");
         try {
             String[] dataDirList = f.list();
             for ( String list : dataDirList){
                 FileInputStream PN1Check = new FileInputStream(f.getPath() + "\\" + list + "\\PN.txt");
                 byte a[] = new byte[PN1Check.available()];
                 while(PN1Check.read(a) != -1){}
                 String data = new String(a);
                 if (PNtext.getText().equals(data))
                 {
                  	return true;
                 }
            }
         }catch (Exception b){
 			 }
         return false;
 	}
	public static void main(String[] args) {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		InfoText info = new InfoText();
		if (e.getSource() == b) {
			dispose();
			new LoginPage();
		}else {
			if(FindIDPN()) {
				dispose();
				info.FindIDMessgae();
				File f = new File("Data");
				String data = "ff";
		         try {
		             String[] dataDirList = f.list();
	                 FileInputStream IDcheck = new FileInputStream(f.getPath() + "\\" + PNtext.getText() + "\\ID.txt");
	                 byte a[] = new byte[IDcheck.available()];
	                 while(IDcheck.read(a) != -1){}
	                 data = new String(a);
	                 data = "ID : " + data;
	                 System.out.println(data);
		         }catch(Exception ex ) {
		         }
		         info.j5.setText(data);	
			}else {
				info.FindIDMessgae();
				info.j5.setText("�Է��Ͻ� ��ȭ��ȣ�� ��ġ�ϴ� ��ȭ��ȣ�� �����ϴ�.");
			}
		}
	}
}
